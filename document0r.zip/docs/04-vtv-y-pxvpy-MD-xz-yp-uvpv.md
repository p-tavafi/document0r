همه ی کدهای MD در یک نگاه
========================

> ما سعی کردیم در کدهای زیر تمام نمونه کدهای `Markdown` را یکجا جمع آوری کنیم

<pre style="float:left; width:45%;">
Title (level 1)
========================
Title (level 2)
-----------------------
### Title (level 3)
#### Title (level 4)
##### Title (level 5)
###### Title (level 6)

Paragraph

**bold**
_italic_
`code`

> Quote

~~~
Code block
~~~

[Text](http://www.example.com)

![picture](img/images.png)
</pre>

<pre style="float:right; width:45%;">
* List,
- List
	- Cadade list
	- Cascade list
+ or List.

1. Numeric list
2. Numeric list
	* Cascade list
	* Cascade list
3. Numeric list

Definition List
: Text

| Header | Header |
| ------ | ------ |
| Cell   | Cell   |
</pre>
	
		